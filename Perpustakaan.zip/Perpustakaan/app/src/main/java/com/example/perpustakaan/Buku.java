package com.example.perpustakaan;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Buku extends AppCompatActivity {
    public Button pinjamBtn;
    ImageView Book1,Book2, Book3, Book4, Book5, Book6, Book7, Book8, Book9, Book10, Book11, Book12, Book13;
    private Button backBtn;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buku);
        backBtn = findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Buku.this, MainActivity.class);
                startActivity(intent);
                Toast.makeText(Buku.this, "Logout Berhasil", Toast.LENGTH_SHORT).show();
                mAuth.signOut();
            }
        });

       pinjamBtn=findViewById(R.id.pinjamBtn);
       pinjamBtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(Buku.this ,AddActivity.class);
               startActivity(intent);
           }
       });

        Book1 = (ImageView) findViewById(R.id.iv_Book1);
        Book2 = (ImageView) findViewById(R.id.iv_Book2);
        Book3 = (ImageView) findViewById(R.id.iv_Book3);
        Book4 = (ImageView) findViewById(R.id.iv_Book4);
        Book5 = (ImageView) findViewById(R.id.iv_Book5);
        Book6 = (ImageView) findViewById(R.id.iv_Book6);
        Book7 = (ImageView) findViewById(R.id.iv_Book7);
        Book8 = (ImageView) findViewById(R.id.iv_Book8);
        Book9 = (ImageView) findViewById(R.id.iv_Book9);
        Book10 = (ImageView) findViewById(R.id.iv_Book10);
        Book11 = (ImageView) findViewById(R.id.iv_Book11);
        Book12 = (ImageView) findViewById(R.id.iv_Book12);
        Book13 = (ImageView) findViewById(R.id.iv_Book13);


        Book1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.jarkom));
                builder.setTitle("Pengantar Jaringan Komputer");
                builder.setMessage("Author : Johan Ericka Wahyu Prakasa" + "\n" + "Kategori : Buku Rferensi" + "\n" + "Tahun : 2018" +
                        "\n" + "Sinopsis : Buku Konsep Dasar Jaringan Komputer ini membahas berbagai konsep dasar jaringan " +
                        "komputer yang harus dipahami " +
                        "sebelum memasuki dunia jaringan komputer. ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.moby));
                builder.setTitle("Moby Dick");
                builder.setMessage("Author : Herman Melville" + "\n" + "Kategori : Buku Novel" + "\n" + "Tahun : 1851" +
                        "\n" + "Sinopsis : Buku ini bercerita tentang petualangan sang tokoh (bernama Ishmael) dalam mengikuti pelayaran kapal pemburu paus yang dipimpin oleh " +
                        "seorang kapten obsesif bernama Kapten Ahab. Sang kapten hanya memiliki satu kaki akibat kecelakaan " +
                        "di kala memburu seekor paus yang dijulukinya Moby-Dick. Ia sangat bernafsu melampiaskan dendamnya kepada sang hewan hingga " +
                        "tidak peduli akan keselamatan diri maupun anak buahnya. ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.harry));
                builder.setTitle("Harry Potter");
                builder.setMessage("Author : J.K Rowling" + "\n" + "Kategori : Buku Novel Fantasi" + "\n" + "Tahun : 2007" +
                        "\n" + "Sinopsis : Novel ini mengisahkan tentang petualangan seorang penyihir remaja bernama Harry Potter dan sahabatnya, " +
                        "Ronald Bilius Weasley dan " +
                        "Hermione Jean Granger, yang merupakan pelajar di Sekolah Sihir Hogwarts.  ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.tokill));
                builder.setTitle("To Kill A Mockingbird");
                builder.setMessage("Author : Harper Lee" + "\n" + "Kategori : Buku Novel;" + "\n" + "Tahun : 1960" +
                        "\n" + "Sinopsis : To Kill a Mockingbird adalah novel karya penulis Amerika Harper Lee . Itu diterbitkan pada tahun 1960 dan langsung sukses. " +
                        "Di Amerika Serikat, itu dibaca secara luas di sekolah menengah dan sekolah menengah. To Kill a Mockingbird telah menjadi sastra klasik " +
                        "Amerika modern , memenangkan Penghargaan Pulitzer . Plot dan karakter secara longgar didasarkan pada pengamatan Lee " +
                        "terhadap keluarganya, tetangganya, dan peristiwa yang terjadi di dekat kampung halamannya di Monroeville, Alabama , pada tahun 1936, " +
                        "ketika dia berusia sepuluh tahun. ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.aplikom));
                builder.setTitle("Aplikasi Komputer");
                builder.setMessage("Author : Dwi Krisbiantaro" + "\n" + "Kategori : Buku Ajar" + "\n" + "Tahun : 2018" +
                        "\n" + "Sinopsis : Buku ini terdiri dari beberapa bab. Bab pertama membahas tentang sejarah dan generasi computer, " +
                        "bab dua membahas tentang microsoft word 2013, bab tiga membahas tentang pemformatan teks, bab empat membahas tentang mailmerge, " +
                        "dan bab lima membahas tentang microsoft excel 2013. Adapun bab enam membahas tentang penggunaan formula dan fungsi, " +
                        "bab tujuh membahas tentang microsoft power point, dan terakhir bab delapan membahas tentang microsoft access ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.berdamai));
                builder.setTitle("Berdamai Dengan Diri Sendiri");
                builder.setMessage("Author : Muthia Sayekti" + "\n" + "Kategori : Buku Novel" + "\n" + "Tahun : 2017" +
                        "\n" + "Sinopsis : Buku ini memberikan sebuah jawaban dari berbagai masalah terkait identitas diri " +
                        "yang kini menjadi sebuah tanda tanya besar. Di dalam buku ini, Anda akan belajar untuk menerima apa adanya," +
                        " berdamai dengan ketidaksempurnaan, dan berdamai untuk menjadi diri sendiri. ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.keringat));
                builder.setTitle("Keringat Tak Pernah Berkhianat");
                builder.setMessage("Author : Ahmad Muliono" +
                        "\n" +
                        "Kategori : Buku Novel" +
                        "\n" +
                        "Tahun : 2017" +
                        "\n" +
                        "Sinopsis : Buku Keirngat Tak Pernah Berkhianat ini menjelaskan alasan mengapa dalam hidup ini kita harus sukses, " +
                        "apa makna sukses yang sesungguhnya, serta langkah-langkah konkret apa saja yang dapat kita lakukan agar berhasil meraih kesuksesan. " +
                        "Semuanya dijelaskan secara gamblang dan nyata oleh penulis dalam buku ini dengan bahasa yang ringan dan " +
                        "mengalir sehingga sangat mudah dibaca dan diambil hikmahnya untuk kita jalankan dalam kehidupan sehari-hari. ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.python));
                builder.setTitle("Python");
                builder.setMessage("Author : Wenty Dwi Yuniarti" +
                        "\n" +
                        "Kategori : Buku Pelajaran" +
                        "\n" +
                        "Tahun : 2017" +
                        "\n" +
                        "Sinopsis : Buku ini disajikan dengan urutan yang memudahkan pembaca dalam memahami konsep pemrograman, mulai dari " +
                        "konsep berpikir algoritmik berorientasi pemecahan masalah, unsur-unsur pemrograman hingga " +
                        "pengenalan paradigma pemrograman berorientasi objek. Namun demikian, pembaca dapat mempelajari sesuai urutan yang dikehendaki. " +
                        "Guna mengasah kemampuan memecahkan masalah dan memprogram, " +
                        "buku ini dilengkapi dengan latihan soal dan praktik memprogram dalam bahasa pemrograman Python menggunakan Jupyter Notebook ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.rajasilat));
                builder.setTitle("Raja Silat");
                builder.setMessage("Author : Jade Liong" +
                        "\n" +
                        "Kategori : Novel Fantasi" +
                        "\n" +
                        "Tahun : 2015" +
                        "\n" +
                        "Sinopsis : Raja Silat aka Lahirnya Dedengkot Silat diawali ketika mengalami kekalahan dari Thian Sian Piauw Cu, " +
                        "Liem Han si Pancingan Sakti membawa Liem Tou anaknya meninggalkan dunia kangouw dan memutuskan menetap sebagai guru sastra di perkampungan " +
                        "Ie Hee Cung di atas puncak Ha Mo Leng. Liem Han bahkan melarang Liem Tou untuk belajar silat. Tak dinyana ia mati diracun oleh sang " +
                        "Cung Cu (Kepala Kampung) yang baru bahkan dengan alasan yang tak jelas sang Cung Cu juga mengusir Liem Tou dari kampungnya, " +
                        "namun disaat terakhir sebelum meninggal Liem Han masih sempat memberikan sejilid kitab sakti perguruannya kepada Liem Tou. ");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.red));
                builder.setTitle("Red Dress In Black and White");
                builder.setMessage("Author : Elliot Ackerman" +
                        "\n" +
                        "Kategori : Novel " +
                        "\n" +
                        "Tahun : 2021" +
                        "\n" +
                        "Sinopsis : Dari penulis Waiting for Eden yang diakui secara luas : novel baru yang menggugah dan tepat waktu yang terungkap " +
                        "di Istanbul selama satu hari, ketika seorang wanita Amerika berusaha meninggalkan kehidupannya di Turki — dan pernikahannya.");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.die));
                builder.setTitle("I Don't Want To Die");
                builder.setMessage("Author : Michael Arceneaux" +
                        "\n" +
                        "Kategori : Novel " +
                        "\n" +
                        "Tahun : 2021" +
                        "\n" +
                        "Sinopsis : Sejak Oprah Winfrey memberi tahu lulusan Universitas Howard tahun 2007, \"Jangan takut,\" Michael Arceneaux ketakutan setengah mati. Anda tidak boleh melakukan kebalikan dari apa yang Oprah perintahkan untuk Anda lakukan, tetapi jika " +
                        "Anda tidak memiliki uang receh, bagaimana mungkin Anda tidak takut akan konsekuensi dari mengejar impian Anda?");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.lamunan));
                builder.setTitle("Lamunan Senja");
                builder.setMessage("Author : Diana Rizky" +
                        "\n" +
                        "Kategori : Novel " +
                        "\n" +
                        "Tahun : 2017" +
                        "\n" +
                        "Sinopsis : Jika Senja dan Fajar terlihat terpisah jarak dan waktu. Akankah Senja dan Fajar mampu bertemu dan bersatu?? Atau tetap akan seperti langit senja dan fajar pagi ??. " +
                        "Gadis yang bernama Senja yang sangat menyukai langit senja. Menikmati senja dengan lamunan-lamunannya. Tentang cinta dan kebencian. Tentang bahagia dan lara. Tentang tangis dan tawanya.\n" +
                        "Fajar pria yang sangat mencintai Senja. Harus rela melepas Senja karena perjodohan yang menghalangi keduanya. Hingga akhirnya cincin tersemat dijari manisnya. Namun sebuah tragedi kecelakaan menimpanya sesaat cincin melingkar dijarinya. Hidup atau mati menjadi pilihan");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
        Book13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Buku.this);
                builder.setIcon(getDrawable(R.drawable.kom));
                builder.setTitle("Komputer Cerdas");
                builder.setMessage("Author : Nur Nafi'iyah" +
                        "\n" +
                        "Kategori : Buku Ajar " +
                        "\n" +
                        "Tahun : 2017" +
                        "\n" +
                        "Sinopsis : Mata kuliah kecerdasan buatan merupakan mata kuliah yang menganjarkan komputer menjadi cerdas. Komputer dapat " +
                        "melakukan pekerjaan yang menyerupai pekerjaan manusia, sehingga dapat membantu aktivitas manusia. " +
                        "Komputer tidak dapat menggantikan keahlian atau kepakaran manusia, akan tetapi membantu agar lebih efisien dan efektif.");
                builder.setPositiveButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.e("Sinopsis", "Keluar");
                            }
                        });
                builder.show();
            }
        });
    }
}